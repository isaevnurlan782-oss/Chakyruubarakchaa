// Жоки & Ариелдин үйлөнүү чакыруу-сайты
// WhatsApp номерин эл аралык форматта, + белгисиз жазыңыз.
// Мисалы: 996700123456. Өз номериңизди коюңуз.
const WHATSAPP_NUMBER = "996XXXXXXXXX";

const opening = document.getElementById("opening");
const invitation = document.getElementById("invitation");
const openButton = document.getElementById("openInvitation");
const music = document.getElementById("weddingMusic");
const musicToggle = document.getElementById("musicToggle");
const musicLabel = document.getElementById("musicLabel");

function setMusicLabel() {
  const playing = !music.paused;
  musicLabel.textContent = playing ? "Музыка өчүрүү" : "Музыка күйгүзүү";
  musicToggle.setAttribute("aria-label", playing ? "Музыканы өчүрүү" : "Музыканы күйгүзүү");
}

openButton.addEventListener("click", async () => {
  opening.classList.add("is-open");
  openButton.disabled = true;
  openButton.textContent = "ЧАКЫРУУ АЧЫЛУУДА…";
  window.setTimeout(() => {
    opening.hidden = true;
    invitation.hidden = false;
    musicToggle.hidden = false;
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, 750);

  try {
    await music.play();
  } catch (error) {
    // Айрым браузерлерде музыка колдонуучу кайра басмайынча башталбашы мүмкүн.
    console.info("Музыканы кол менен күйгүзүү керек болушу мүмкүн.", error);
  }
  setMusicLabel();
});

musicToggle.addEventListener("click", async () => {
  if (music.paused) {
    try { await music.play(); } catch (error) { console.error(error); }
  } else {
    music.pause();
  }
  setMusicLabel();
});

music.addEventListener("play", setMusicLabel);
music.addEventListener("pause", setMusicLabel);

// Той күнү: 30-декабрь 2026-жыл, саат 17:00 (Кыргызстан убактысы, UTC+6).
const weddingDate = new Date("2026-12-30T17:00:00+06:00").getTime();
const countdownNote = document.getElementById("countdownNote");

function updateCountdown() {
  const now = Date.now();
  const difference = weddingDate - now;
  if (difference <= 0) {
    ["days", "hours", "minutes", "seconds"].forEach(id => {
      document.getElementById(id).textContent = "00";
    });
    countdownNote.textContent = "Бүгүн биздин өзгөчө күнүбүз! Майрамыбызга кош келиңиздер!";
    return;
  }
  const days = Math.floor(difference / 86400000);
  const hours = Math.floor((difference % 86400000) / 3600000);
  const minutes = Math.floor((difference % 3600000) / 60000);
  const seconds = Math.floor((difference % 60000) / 1000);
  document.getElementById("days").textContent = String(days).padStart(2, "0");
  document.getElementById("hours").textContent = String(hours).padStart(2, "0");
  document.getElementById("minutes").textContent = String(minutes).padStart(2, "0");
  document.getElementById("seconds").textContent = String(seconds).padStart(2, "0");
}
updateCountdown();
window.setInterval(updateCountdown, 1000);

// RSVP формасы WhatsApp'ка даяр билдирүү түзөт.
// Номер коюлбаса, форма маалыматты көрсөтүп, номерди конфигурациялоону эскертет.
const rsvpForm = document.getElementById("rsvpForm");
const formStatus = document.getElementById("formStatus");
const directWhatsapp = document.getElementById("directWhatsapp");

function makeWhatsAppUrl(message) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

directWhatsapp.href = makeWhatsAppUrl(
  "Саламатсыздарбы! Жоки жана Ариелдин үйлөнүү тою боюнча жооп берейин дегем."
);

rsvpForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const formData = new FormData(rsvpForm);
  const name = String(formData.get("guestName") || "").trim();
  const attendance = String(formData.get("attendance") || "");
  const guestCount = String(formData.get("guestCount") || "1");
  const note = String(formData.get("guestNote") || "").trim();

  const message = [
    "Саламатсыздарбы! Жоки жана Ариелдин үйлөнүү тою боюнча жооп:",
    `Аты-жөнү: ${name}`,
    `Жообу: ${attendance}`,
    `Коноктордун саны: ${guestCount}`,
    note ? `Кошумча билдирүү: ${note}` : ""
  ].filter(Boolean).join("\n");

  if (WHATSAPP_NUMBER.includes("X")) {
    formStatus.textContent = "WhatsApp номерин script.js файлындагы WHATSAPP_NUMBER жерине киргизүү керек. Азырынча билдирүү даярдалды.";
    const preview = window.open("", "_blank");
    if (preview) {
      preview.document.write(`<pre style="white-space:pre-wrap;font:16px sans-serif;padding:20px">${message.replace(/[&<>"]/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[ch]))}</pre>`);
      preview.document.title = "RSVP билдирүүсү";
    }
    return;
  }
  window.open(makeWhatsAppUrl(message), "_blank", "noopener");
  formStatus.textContent = "WhatsApp ачылды. Билдирүүнү жөнөтүү үчүн WhatsApp'та «Жөнөтүү» баскычын басыңыз.";
});
